package org.example.service;  // Specifies the package where the service class is located.

import org.springframework.stereotype.Service;  // Imports the @Service annotation, which marks the class as a Spring service.

import java.time.LocalTime;  // Imports the LocalTime class from the java.time package, which is used to work with times.

@Service  // Marks this class as a Spring-managed service, making it eligible for dependency injection.
public class CheckService {  // Defines the CheckService class, which contains the logic for checking in and checking out.

    // Sets the allowed check-in and check-out times.
    private final LocalTime checkInTime = LocalTime.of(12, 0);  // The allowed check-in time starts at 12:00 PM (noon).
    private final LocalTime latestCheckInTime = LocalTime.of(17, 0);  // The latest check-in time is 5:00 PM.
    private final LocalTime checkOutTime = LocalTime.of(11, 0);  // The required check-out time is 11:00 AM.

    public void checkIn(String bookingRef) throws Exception {  // Defines the check-in method, which accepts a booking reference as input and can throw an exception.
        validateBooking(bookingRef);  // Validates the booking reference to ensure it's valid.
        validateCheckInTime();  // Validates whether the current time is within the allowed check-in time.
    }

    public void checkOut(String bookingRef) throws Exception {  // Defines the check-out method, which accepts a booking reference as input and can throw an exception.
        validateBooking(bookingRef);  // Validates the booking reference to ensure it's valid.
        validateCheckOutTime();  // Validates whether the current time is before the check-out deadline.
    }

    private void validateBooking(String bookingRef) throws Exception {  // Private method to validate the booking reference.
        if (!"validRef".equals(bookingRef)) {  // Checks if the provided booking reference matches "validRef" (a placeholder for a real reference).
            throw new Exception("Invalid booking reference");  // Throws an exception if the booking reference is not valid.
        }
    }

    private void validateCheckInTime() throws Exception {  // Private method to validate whether the current time is within the check-in window.
        LocalTime now = LocalTime.now();  // Gets the current system time.
        if (now.isBefore(checkInTime)) {  // Checks if the current time is before 12:00 PM (noon).
            throw new Exception("Check-in time is after 12 noon");  // Throws an exception if trying to check in too early.
        }
        if (now.isAfter(latestCheckInTime)) {  // Checks if the current time is after 5:00 PM.
            throw new Exception("Check-in time is before 5 PM");  // Throws an exception if trying to check in too late.
        }
    }

    private void validateCheckOutTime() throws Exception {  // Private method to validate whether the current time is before the check-out deadline.
        if (LocalTime.now().isAfter(checkOutTime)) {  // Checks if the current time is after 11:00 AM (the check-out time).
            throw new Exception("Check-out time is before 11 AM");  // Throws an exception if trying to check out after 11:00 AM.
        }
    }
}