package org.example.service;  // Specifies the package where the test class is located.

public class CheckServiceTest {  // Defines a test class for CheckService, containing test cases to verify the service's behavior.

    private CheckService checkService;  // Declares a reference to the CheckService class, which will be tested.

    public void setUp() {  // A setup method to initialize the CheckService before running the tests.
        checkService = new CheckService();  // Instantiates the CheckService object, preparing it for the test cases.
    }

    public void testCheckInBeforeNoonThrowsException() {  // Defines a test method to check if an exception is thrown for an invalid check-in.
        try {
            checkService.checkIn("invalidRef");  // Attempts to call the checkIn method with an invalid booking reference.
            System.out.println("Test failed: No exception thrown for check-in");  // If no exception is thrown, the test fails, and this message is printed.
        } catch (Exception e) {  // Catches any exception thrown during the check-in process.
            System.out.println("Test passed: " + e.getMessage());  // If an exception is caught, the test passes, and the exception message is printed.
        }
    }

    public void testCheckOutAfter11amThrowsException() {  // Defines a test method to check if an exception is thrown for an invalid check-out.
        try {
            checkService.checkOut("invalidRef");  // Attempts to call the checkOut method with an invalid booking reference.
            System.out.println("Test failed: No exception thrown for check-out");  // If no exception is thrown, the test fails, and this message is printed.
        } catch (Exception e) {  // Catches any exception thrown during the check-out process.
            System.out.println("Test passed: " + e.getMessage());  // If an exception is caught, the test passes, and the exception message is printed.
        }
    }

    public static void main(String[] args) {  // The main method, which is the entry point for running the test cases.
        CheckServiceTest test = new CheckServiceTest();  // Creates an instance of CheckServiceTest to run the tests.
        test.setUp();  // Calls the setUp method to initialize CheckService before running the tests.

        System.out.println("Running testCheckInBeforeNoonThrowsException...");  // Prints a message indicating the first test is about to run.
        test.testCheckInBeforeNoonThrowsException();  // Runs the test case to verify if an exception is thrown for check-in.

        System.out.println("\nRunning testCheckOutAfter11amThrowsException...");  // Prints a message indicating the second test is about to run.
        test.testCheckOutAfter11amThrowsException();  // Runs the test case to verify if an exception is thrown for check-out.
    }
}