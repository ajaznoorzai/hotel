package org.example.controller;  // Specifies the package where this controller class is located.

import org.example.service.CheckService;  // Imports the CheckService class, which contains the check-in and check-out logic.
import org.springframework.beans.factory.annotation.Autowired;  // Enables Spring to automatically inject dependencies (in this case, CheckService).
import org.springframework.http.ResponseEntity;  // Provides a convenient way to create HTTP responses with various status codes and body content.
import org.springframework.web.bind.annotation.*;  // Imports annotations like @RestController, @RequestMapping, @PostMapping, etc., which are used to define the REST API.

@RestController  // Indicates that this class will handle REST API requests and responses.
@RequestMapping("/api/v1/virtual")  // Maps all endpoints in this controller to start with "/api/v1/virtual".
public class VirtualCheckController {  // Defines the class that serves as a controller for handling check-in and check-out requests.

    @Autowired  // Tells Spring to automatically inject an instance of CheckService into this controller.
    private CheckService checkService;  // A reference to the CheckService class, which contains the business logic for check-in and check-out.

    @PostMapping("/checkin")  // Defines a POST endpoint at "/api/v1/virtual/checkin" to handle check-in requests.
    public ResponseEntity<String> checkIn(@RequestParam String bookingRef) {  // The checkIn method takes a query parameter (bookingRef) and returns an HTTP response.
        try {
            checkService.checkIn(bookingRef);  // Calls the checkIn method in the CheckService class with the bookingRef as input.
            return ResponseEntity.ok("Check-in successful");  // If no exception occurs, return a 200 OK response with the message "Check-in successful".
        } catch (Exception e) {  // Catches any exception that occurs during check-in.
            return ResponseEntity.badRequest().body(e.getMessage());  // Returns a 400 Bad Request response with the exception message as the response body.
        }
    }

    @PostMapping("/checkout")  // Defines a POST endpoint at "/api/v1/virtual/checkout" to handle check-out requests.
    public ResponseEntity<String> checkOut(@RequestParam String bookingRef) {  // The checkOut method takes a query parameter (bookingRef) and returns an HTTP response.
        try {
            checkService.checkOut(bookingRef);  // Calls the checkOut method in the CheckService class with the bookingRef as input.
            return ResponseEntity.ok("Check-out successful");  // If no exception occurs, return a 200 OK response with the message "Check-out successful".
        } catch (Exception e) {  // Catches any exception that occurs during check-out.
            return ResponseEntity.badRequest().body(e.getMessage());  // Returns a 400 Bad Request response with the exception message as the response body.
        }
    }
}