package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualCheckApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(VirtualCheckApiApplication.class, args);
    }
}
