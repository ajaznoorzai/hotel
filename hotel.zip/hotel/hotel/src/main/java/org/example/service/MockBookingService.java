package org.example.service;

import org.springframework.stereotype.Component;

@Component
public class MockBookingService {

    public boolean isValidBooking(String bookingRef) {
        return "validRef".equals(bookingRef);
    }
}
