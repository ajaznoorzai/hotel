rootProject.name = "hotel"

