plugins {
    id("java")
    id("org.springframework.boot") version "3.1.3"
    id("io.spring.dependency-management") version "1.0.15.RELEASE"
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}
dependencies {
    testImplementation("org.testng:testng:7.7.0")
    implementation("org.springframework.boot:spring-boot-starter-web")
    testImplementation("org.mockito:mockito-core:4.7.0")
}

tasks.test {
    useTestNG()
}


